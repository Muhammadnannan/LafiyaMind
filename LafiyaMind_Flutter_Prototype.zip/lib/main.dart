import 'package:flutter/material.dart';

void main() => runApp(const LafiyaMindApp());

class LafiyaMindApp extends StatelessWidget {
  const LafiyaMindApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'LafiyaMind',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF137A54)),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF7FAF8),
      ),
      home: const ScreeningPage(),
    );
  }
}

class ScreeningPage extends StatefulWidget {
  const ScreeningPage({super.key});

  @override
  State<ScreeningPage> createState() => _ScreeningPageState();
}

class _ScreeningPageState extends State<ScreeningPage> {
  String language = 'ha';
  final Map<int, int> answers = {};
  String safetyAnswer = '';

  bool get isHausa => language == 'ha';
  int get score => answers.values.fold(0, (sum, value) => sum + value);

  final List<Map<String, String>> questions = const [
    {
      'ha': 'A cikin makonni biyu da suka wuce, sau nawa ka ji baƙin ciki ko rashin bege?',
      'en': 'Over the past two weeks, how often have you felt sad or hopeless?',
    },
    {
      'ha': 'Sau nawa ka rasa sha’awar abubuwan da ka saba jin daɗinsu?',
      'en': 'How often have you had little interest or pleasure in doing things?',
    },
    {
      'ha': 'Sau nawa ka samu matsalar bacci ko ka yi bacci fiye da yadda ka saba?',
      'en': 'How often have you had trouble sleeping or slept more than usual?',
    },
    {
      'ha': 'Sau nawa ka ji gajiya ko rashin kuzari?',
      'en': 'How often have you felt tired or had little energy?',
    },
    {
      'ha': 'Sau nawa ka samu matsalar mayar da hankali kan aikinka ko karatunka?',
      'en': 'How often have you had difficulty concentrating on work or study?',
    },
  ];

  List<String> get options => isHausa
      ? ['Ko kaɗan', 'Wasu kwanaki', 'Fiye da rabin kwanakin', 'Kusan kowace rana']
      : ['Not at all', 'Several days', 'More than half the days', 'Nearly every day'];

  void reset() {
    setState(() {
      answers.clear();
      safetyAnswer = '';
    });
  }

  void showResult() {
    final needsUrgentSupport = safetyAnswer == 'yes' || safetyAnswer == 'unsure';
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(isHausa ? 'Sakamakon tantancewar farko' : 'Initial screening result'),
        content: SingleChildScrollView(
          child: Text(
            needsUrgentSupport
                ? (isHausa
                    ? 'Amsarka tana nuna cewa ya dace ka nemi taimakon ƙwararren lafiyar kwakwalwa cikin gaggawa. Idan kana jin za ka iya cutar da kanka yanzu, kada ka zauna kai kaɗai; ka sanar da wanda ka amince da shi kuma ka nemi taimakon gaggawa.'
                    : 'Your response indicates that urgent support from a mental health professional is appropriate. If you may harm yourself now, stay with someone you trust and seek emergency help.')
                : '${isHausa ? 'Jimillar amsoshin alamomi' : 'Symptom response total'}: $score / 15\n\n'
                    '${score <= 4 ? (isHausa ? 'Amsoshinka sun nuna ƙarancin alamomin da aka tambaya. Wannan ba yana tabbatar da cewa babu matsala ba.' : 'Your answers indicate relatively few symptoms among those asked. This does not rule out a mental health concern.') : score <= 9 ? (isHausa ? 'Amsoshinka sun nuna wasu alamomin da ya kamata ka kula da su. Idan suna damunka ko suna shafar rayuwarka, ka yi magana da ƙwararren lafiya.' : 'Your answers indicate some symptoms worth paying attention to. If they distress you or affect daily life, speak with a health professional.') : (isHausa ? 'Amsoshinka sun nuna alamomi masu yawa a cikin tambayoyin nan. Ana ba da shawarar ka nemi tantancewa daga ƙwararren lafiyar kwakwalwa.' : 'Your answers indicate a higher level of symptoms on these questions. Consider an assessment by a mental health professional.')}\n\n'
                    '${isHausa ? 'Wannan samfurin gwaji ne kawai; ba a tabbatar da shi a matsayin ma’aunin likitanci ba, kuma ba ya gano wata cuta.' : 'This is an experimental prototype, not a validated clinical measure, and it does not diagnose a condition.'}',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              reset();
            },
            child: Text(isHausa ? 'Sake gwadawa' : 'Try again'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(isHausa ? 'Rufe' : 'Close'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('LafiyaMind'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: DropdownButton<String>(
              value: language,
              underline: const SizedBox.shrink(),
              items: const [
                DropdownMenuItem(value: 'ha', child: Text('Hausa')),
                DropdownMenuItem(value: 'en', child: Text('English')),
              ],
              onChanged: (value) {
                if (value != null) setState(() => language = value);
              },
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: const Color(0xFFDDF5E8),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.psychology_alt, size: 42, color: Color(0xFF137A54)),
                  const SizedBox(height: 8),
                  Text(
                    isHausa ? 'Yaya kake ji a kwanakin nan?' : 'How have you been feeling lately?',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 6),
                  Text(isHausa
                      ? 'Amsa tambayoyin nan bisa yadda ka ji a makonni biyu da suka wuce.'
                      : 'Answer based on how you have felt over the past two weeks.'),
                ],
              ),
            ),
            const SizedBox(height: 12),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Text(
                  isHausa
                      ? 'Muhimmi: Wannan kayan gwaji ne kawai, ba ya gano cuta ko maye gurbin likita. Idan kana cikin haɗari yanzu, nemi taimakon gaggawa.'
                      : 'Important: This is a prototype only; it does not diagnose conditions or replace a clinician. If you are in immediate danger, seek emergency help.',
                ),
              ),
            ),
            const SizedBox(height: 8),
            ...List.generate(questions.length, (index) {
              return Card(
                margin: const EdgeInsets.only(bottom: 12),
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${index + 1}. ${questions[index][language]}',
                        style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
                      ),
                      const SizedBox(height: 8),
                      ...List.generate(options.length, (optionIndex) {
                        return RadioListTile<int>(
                          contentPadding: EdgeInsets.zero,
                          dense: true,
                          title: Text(options[optionIndex]),
                          value: optionIndex,
                          groupValue: answers[index],
                          onChanged: (value) {
                            if (value != null) setState(() => answers[index] = value);
                          },
                        );
                      }),
                    ],
                  ),
                ),
              );
            }),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      isHausa
                          ? 'Tambayar tsaro: A cikin makonni biyu da suka wuce, ka yi tunanin cutar da kanka ko kashe kanka?'
                          : 'Safety question: In the past two weeks, have you had thoughts of harming yourself or ending your life?',
                      style: const TextStyle(fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(height: 8),
                    for (final item in [
                      ['no', isHausa ? 'A’a' : 'No'],
                      ['yes', isHausa ? 'Eh' : 'Yes'],
                      ['unsure', isHausa ? 'Ban tabbata ba' : 'Not sure'],
                    ])
                      RadioListTile<String>(
                        contentPadding: EdgeInsets.zero,
                        title: Text(item[1]),
                        value: item[0],
                        groupValue: safetyAnswer,
                        onChanged: (value) => setState(() => safetyAnswer = value ?? ''),
                      ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            FilledButton(
              onPressed: answers.length == questions.length && safetyAnswer.isNotEmpty ? showResult : null,
              child: Text(isHausa ? 'Duba sakamakon gwaji' : 'View screening result'),
            ),
            const SizedBox(height: 20),
            Center(
              child: Text(
                'LafiyaMind • Prototype 0.1',
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
