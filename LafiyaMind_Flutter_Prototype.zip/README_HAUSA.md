# LafiyaMind — samfurin Flutter

Wannan shi ne samfurin farko na manhajar Android don taimakawa jama'a su yi tunani kan wasu alamomin lafiyar kwakwalwa. Yana da Hausa da Turanci.

## Muhimmin gargadi
- Wannan samfurin ba ya gano cuta kuma ba ma'aunin likitanci da aka tabbatar ba ne.
- Kada a yi amfani da sakamakonsa wajen yanke shawarar magani.
- Kafin a fitar da shi ga jama'a, ƙwararrun lafiyar kwakwalwa su duba tambayoyi, sakamako, fassara, da hanyoyin taimakon gaggawa.
- Samfurin ba ya aika ko adana amsoshi a uwar garke.

## Yadda za a kunna shi
1. Sanya Flutter SDK da Android Studio.
2. Buɗe terminal a cikin wannan babban fayil.
3. Gudanar da `flutter pub get`.
4. Haɗa wayar Android (USB debugging a kunne) ko fara emulator.
5. Gudanar da `flutter run`.

## Gina APK
Gudanar da `flutter build apk --release`.
Idan an kammala ba tare da kuskure ba, fayil ɗin APK zai kasance a:
`build/app/outputs/flutter-apk/app-release.apk`

## Matakan da suka rage kafin amfani na gaske
- Ƙwararren likita ya amince da ma'aunin tantancewa da tsarin fassara maki.
- Inganta hanyar amsa ga haɗarin cutar da kai, ciki har da lambobin taimakon gaggawa da suka dace da ƙasar mai amfani.
- Gwajin tsaro, sirri, sauƙin amfani da daidaiton fassarar Hausa da Turanci.
